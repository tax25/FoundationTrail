# Aodoo

Aodoo - an odoo module generator/helper

After developing modules for Odoo for almost a year now, i noticed that there are some operations that are quite repetitive while developing for Odoo.

The aim of Aodoo is to automate all those processes (module creation, model creation, view creation, etc...) so that one can fully concentrate on developing the actual model rather than on creating the boilerplate.

This is a really immature project. Some functionalities are already developed.


