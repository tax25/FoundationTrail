import sys
import re

from aodoo import __version__

from aodoo.operationHandlers import generate_module_handler as module_h
from aodoo.operationHandlers import generate_security_handler as sec_h
from aodoo.operationHandlers import generate_model_handler as model_h
from aodoo.operationHandlers import generate_view_handler as view_h
from aodoo.operationHandlers.send_help import send_help


# @todo(allow the user to specify dependencies on module, model and view generation. In case of view generation, even the inherit_id)
# @todo(at module/application generation maybe generate an __init__.py file in wizards/?)
# @todo(at view generation allow the user to pass the model for which the view is being created.)
# @todo(...continues: and maybe in the future allow the user to pass even the inherit_id and other view params)
# @todo(Allow the user to create security groups)

def _get_param_from_command_line(index, arguments):
    
    if len(arguments) > index: 
        return arguments[index]

    return False


def handle_generate(what_to_generate: str, name: str):

    name = re.sub(r'(?<!^)(?=[A-Z])', '_', name.replace(' ', '_')).lower()
    
    match what_to_generate:
        case 'application' | 'a':
            module_h.handle_generate_module(name, True)
            
        case 'module' | 'm':
            module_h.handle_generate_module(name, False)
        
        case 'view' | 'v':
            view_h.handle_generate_view(name.replace('.xml', ''))
        
        case 'model' | 'M': 
            model_h.handle_generate_model(name.replace('.py', ''))
        
        case 'security' | 's':
            sec_h.handle_generate_security(name)


def main(given_action: str, given_detail: str, given_name: str):
    
    match given_action:
        case 'generate' | 'g':
            assert given_detail and given_name, "Not enough params!"
            handle_generate(what_to_generate=given_detail, name=given_name)
        case _:
            # handle non existent
            print("The function you inserted does not exist! Here's some help:")
            send_help()


def aodoo_entrypoint():
    if len(sys.argv) == 1:
        send_help()
        sys.exit()

    if '--version' in sys.argv or '-v' in sys.argv:
        print("Your installed Aodoo version is: ", __version__)
        sys.exit()
    
    action = _get_param_from_command_line(1, sys.argv)
    detail = _get_param_from_command_line(2, sys.argv)
    name = _get_param_from_command_line(3, sys.argv)

    main(action, detail, name)
    

if __name__ == '__main__': # for testing purposes
    aodoo_entrypoint()
