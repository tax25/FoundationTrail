import os
import json
import platform

def _get_end_directory():

    match platform.system():

        case 'Darwin':
            return f'/Users/{os.getlogin()}'
        case 'Linux':
            return '/home'


MANIFEST_FILENAME = '__manifest__.py'
END_DIRECTORY = _get_end_directory()

def handle_generate_view(view_name: str):
    
    # create file
    file_name = ""
    file_name_and_path = ''
    if 'views' in os.getcwd():
        file_name = f'views/{view_name}.xml'
        file_name_and_path = os.getcwd() + f'/{file_name}'
    elif os.path.exists(os.getcwd() + '/views'):
        file_name = f'views/{view_name}.xml'
        file_name_and_path = os.getcwd() + f'/views/{view_name}.xml'
    elif os.path.exists(os.getcwd() + '../views'): # in case the user is in the models directory for example
        file_name = f'views/{view_name}.xml'
        file_name_and_path = os.getcwd() + f'/../views/{view_name}.xml'
    else:
        print(f"Cannot find /views directory so creating the file in current directory ({os.getcwd()})")
        file_name = f'{view_name}.xml'
        file_name_and_path = os.getcwd() + f'/{view_name}.xml'

    # sarebbe figo trovare il nome del modulo e metterlo nel name="model".
    # un ottima cosa sarebbe poter specificare la creazione di una view inherit
    # e quindi poi mettere il giusto model, etc...
    with open(file_name_and_path, 'w') as view_file:    
        basic_view_file_string = f"""<?xml version="1.0" encoding="utf-8"?>
<odoo>

    <data>

        <record id="{view_name}" model="ir.ui.view">
            <field name="name">{view_name.replace('_', '.')}</field>
            <field name="model"></field>
            <field name="arch" type="xml">

            </field>
        </record>

    </data>

</odoo>
"""
        view_file.write(basic_view_file_string)
    
    # add file to __manifest__.py
    manifest_file_path = ''
    # module_name = ''
    if not os.path.isfile(MANIFEST_FILENAME):
        os.chdir('..') 
        while True:
            if not os.path.isfile(MANIFEST_FILENAME):
                os.chdir('..')
            else:
                manifest_file_path = os.path.abspath(os.curdir)
                # taking the last argument as the module name 
                # is the current directory
                # module_name = manifest_file_path.split('/')[-1]
                break

            if os.path.abspath(os.curdir) == END_DIRECTORY :
                print("ERROR: __manifest__.py file not found! View is generated, but not added to __manifest__.py")
                return
    else:
        manifest_file_path = os.path.abspath(os.curdir)
        # module_name = manifest_file_path.split('/')[-1]

    with open(manifest_file_path + '/__manifest__.py', 'r+') as manifest:
        manifest_dict = json.loads(
            manifest.read()
                .replace('\n', '')
                .replace('\t', '')
                .replace("'", '"')
                .replace('False', 'false')
                .replace('True', 'true')
                .replace(',}', '}')
        )
            
        manifest_dict['data'].append(file_name)
        
        manifest.seek(0)
        
        manifest.write(json.dumps(manifest_dict, indent=4).replace('true', 'True').replace('false', 'False'))
        
        manifest.truncate()
        
        print(f"View file created and added to the __manifest__.py as {file_name}")
        





