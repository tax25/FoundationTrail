def handle_generate_security(name):
	print("handle generate security")